<?php include('cabecalho.php') ?>

<section style="background-color: #2aabd2">

    <div class="col-md-offset-4 div_layout"><h1>Testando Efeitos</h1></div>


</section>

<script src="<?= base_url("js/bootstrap.min.js") ?>"></script>

<script src="<?= base_url("js/jquery-1.12.4.js") ?>"></script>
<script src="<?= base_url("js/jquery-1.12.0-ui.js") ?>"></script>
<script src="<?= base_url("js/jscript.js") ?>"></script>
</body>
</html>


