

<?php var_dump($clientes); ?>
