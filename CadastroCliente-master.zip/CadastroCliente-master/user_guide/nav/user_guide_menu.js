window.onload = function() {
	myHeight = new fx.Height('nav', {duration: 400});
	myHeight.hide();
}